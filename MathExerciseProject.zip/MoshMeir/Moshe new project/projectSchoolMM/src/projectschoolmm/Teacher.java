package projectschoolmm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Teacher extends Person {
    private String[] professions; 
    private int current=0;

    public Teacher(int age, String cardId, String name) {
        super(age, cardId, name);
        professions = new String[5];
    }
    
    public void addProfession(String profession){
        if(current<professions.length){
            professions[current]=profession;
            current++;
        }
    }
    public void printDetails(){
        super.printDetails();
        for(int i=0; i<current; i++){
            System.out.println("profession "+(i+1)+" is "+professions[i]);
        }
        System.out.println("____________________________");
    }
    public boolean isTeachingProfession(String profession){
        boolean flag = false;
        for(int i=0; i<current; i++){
            if(professions[i].equals(profession))
                flag=true;
        }
        return flag;
    }    

}
