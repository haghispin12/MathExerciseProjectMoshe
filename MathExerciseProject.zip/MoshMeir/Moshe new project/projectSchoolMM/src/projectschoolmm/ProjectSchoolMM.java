/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectschoolmm;

/**
 *
 * @author user
 */
public class ProjectSchoolMM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Student st1 = new Student(96, 16, "331","Jim");
        Student st2 = new Student(94, 16, "332","James");
        Teacher t1 = new Teacher(47,"222","Jerald");
        Teacher t2 = new Teacher(58,"221","Jeremy");
        Person[] persons = new Person[4];
        persons[0]=st1;
        persons[1]=st2;
        persons[2]=t1;
        persons[3]=t2;
        t1.addProfession("Math");
        t1.addProfession("English");
        t1.addProfession("History");
        t2.addProfession("Math");
        t2.addProfession("English");
        t2.addProfession("History");
        persons[0].printDetails();
        persons[1].printDetails();
        persons[2].printDetails();
        persons[3].printDetails();
    }

}
