package projectschoolmm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Student extends Person {
     int avg;
    
    public Student(int avg, int age, String cardId, String name){
        super(age, cardId, name);
        this.avg=avg;
    }
    
    /**
     *
     */
    @Override
    public void printDetails(){
        super.printDetails();
        System.out.println("Average: "+avg);
        System.out.println("____________________________");
    }

}
