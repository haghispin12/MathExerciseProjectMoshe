package projectschoolmm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Person {
    private String cardId;
    private String name;
    private int age;
    public Person(int age, String cardId, String name){
        this.cardId=cardId;
        this.age=age;
        this.name=name;
    }
    
    /**
     *
     */
    public void printDetails(){
        System.out.println("Name: "+this.name);
        System.out.println("Age: "+this.age);
        System.out.println("CardId: "+this.cardId);
    }
    

}
